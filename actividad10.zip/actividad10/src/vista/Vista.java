/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vista;

/**
 *
 * @author ximena
 */
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Vista extends JFrame{
    
    public JButton CANINO, FELINO;
    public JLabel mensaje1, mensaje2;
    private JPanel panel;
    
    public Vista() {                        
        
        getContentPane().setLayout(new BorderLayout());
        
        panel = new JPanel();
        panel.setLayout(new FlowLayout());        
        
        CANINO = new JButton("CANINO");
        FELINO = new JButton("FELINO");
        
        mensaje1 = new JLabel("RESCATE Y ADOPCÔN DE MASCOTAS.");        
        mensaje2 = new JLabel("¿QUÈ TIPO DE ANIMAL DESSEA REGISTRAR?");
        
        panel.setBackground(new java.awt.Color(204, 204, 255));
        panel.setForeground(new java.awt.Color(0, 0, 0));
        FELINO.setBackground(new java.awt.Color(255, 204, 204));
        FELINO.setForeground(new java.awt.Color(0, 0, 0));
        CANINO.setBackground(new java.awt.Color(255, 204, 204));
        CANINO.setForeground(new java.awt.Color(0, 0, 0));
        panel.add(mensaje1);
        panel.add(mensaje2);
        panel.add(CANINO);
        panel.add(FELINO);                        
        
        add(panel, BorderLayout.CENTER);     
        
    }

  
   
}
