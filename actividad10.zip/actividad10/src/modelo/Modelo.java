/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author ximena
 */
public class Modelo {
    
       private String nombre,raza,color,especial,edad;

        public Modelo() {
            
        }
                            
        public Modelo(String nombre, String raza, String color, String edad, String especial) {
        
            this.nombre = nombre;
            this.raza = raza;
            this.color = color;
            this.especial = especial;
            this.edad = edad;
        
        }                
        
        public String getNombre() {
            return nombre;
        }
        public void setNombre(String nombre) {
            this.nombre = nombre;
        }
        public String getRaza() {
            return raza;
        }
        public void setRaza(String raza) {
            this.raza = raza;
        }
        public String getColor() {
            return color;
        }
        public void setColor(String color) {
            this.color = color;
        }
        public String getEspecial() {
            return especial;
        }
        public void setEspecial(String nivEntrenamiento) {
            this.especial = nivEntrenamiento;
        }
        public String getEdad() {
            return edad;
        }
        public void setEdad(String edad) {
            this.edad = edad;
        } 
   
}

