/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

/**
 *
 * @author ximena
 */
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import modelo.Modelo;
import vista.*;

public class Controlador implements ActionListener{
    
    private Modelo modelo;
    private Vista vista1;
    
    public Controlador(Modelo modelo, Vista vista1) {
        
        this.modelo = modelo;
        this.vista1 = vista1;
        this.vista1.CANINO.addActionListener(this);
        this.vista1.FELINO.addActionListener(this);
        
    }

    
    public void iniciarVista() {
        
        vista1.setTitle("Adopciòn de mascotas");
        vista1.setPreferredSize(new Dimension(300,100));
        vista1.pack();
        vista1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        vista1.setLocationRelativeTo(null);
        vista1.setVisible(true);
        
    }
    
    public void actionPerformed(ActionEvent evento) {
        
        if(vista1.CANINO == evento.getSource()) {
            
            Canino perro = new Canino(null, false);
            perro.setVisible(true);
            
        }else if(vista1.FELINO == evento.getSource()) {
            
            Felino gato = new Felino(null, false);
            gato.setVisible(true);
            
        }
        
    }
    
    
    
}

    
